package com.capgemini.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.capgemini.test.TestBase;

public class Personal {
	
	WebDriver driver;
	
	@FindBy(name="empno")
	WebElement empno;
	
	@FindBy(name="name")
	WebElement name;
	
	@FindBy(name="city")
	WebElement cityName;
	
	@FindBy(name="state")
	WebElement state;
	
	@FindBy(name="Submit Button")
	WebElement submit;
	
	
	

	public Personal() throws InterruptedException {
		super();
		driver=TestBase.Initialisation();
		driver.get(
				"C:\\sts-bundle\\BDD_Module3\\EmployeePOMExampleWithAnnotation\\WebContent\\Personal.html");
		PageFactory.initElements(driver, this);
		Thread.sleep(1000);
	}
	
	
	public void setEmployeeDetails(String arg1, String arg2, String arg3, String arg4) throws InterruptedException
	{
//		WebElement id = empno;
		empno.click();
		empno.sendKeys(arg1);
		Thread.sleep(1000);

//		WebElement name = driver.findElement(By.name(""));
		name.click();
		name.sendKeys(arg2);
		Thread.sleep(1000);

		Select city = new Select(cityName);
		city.selectByVisibleText(arg3);

//		WebElement state = driver.findElement(By.name("state"));
		state.click();
		state.sendKeys(arg4);
		Thread.sleep(1000);
	}
	
	
	public void submitDetails()
	{
		submit.click();
	}
	
	
	public String getTitle()
	{
		String title=driver.getTitle();
		return title;
	}
	
	
	public void quitPage()
	{
		driver.close();
	}
	
	
	public String getMessage()
	{
		String alertMessage=null;
		if (this.isAlertPresent()) {
			alertMessage=driver.switchTo().alert().getText();
			driver.switchTo().alert().accept();
		}
		return alertMessage;
	}
	
	
	public boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			return true;
		} catch (Exception e) {
			return false;
		}
	}
	
	
	

}
