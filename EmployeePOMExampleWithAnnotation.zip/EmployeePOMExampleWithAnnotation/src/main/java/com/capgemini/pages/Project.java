package com.capgemini.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.capgemini.test.TestBase;

public class Project {
	WebDriver driver;
	
	@FindBy(name="name")
	WebElement name;
	
	@FindBy(name="Submit Button")
	WebElement submit;
	

	public Project() throws InterruptedException {
		super();
		
		
		driver=TestBase.Initialisation();
		driver.get(
				"C:\\sts-bundle\\BDD_Module3\\EmployeePOMExampleWithAnnotation\\WebContent\\Project.html");
		PageFactory.initElements(driver, this);
		Thread.sleep(1000);
	}
	
	public void setProjectDetails(String arg1, String arg2) throws InterruptedException
	{
		name.click();
		name.sendKeys(arg1);
		Thread.sleep(1000);

		driver.findElement(By.cssSelector("input[value='"+arg2+"']")).click();
	}
	
	
	public void submitDetails()
	{
		submit.click();
	}
	
	
	public String getTitle()
	{
		String title=driver.getTitle();
		return title;
	}
	
	public void quitPage()
	{
		driver.close();
	}
	
	
	public String getMessage()
	{
		String alertMessage=null;
		if (this.isAlertPresent()) {
			alertMessage=driver.switchTo().alert().getText();
			driver.switchTo().alert().accept();
		}
		return alertMessage;
	}
	
	
	public boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			return true;
		} catch (Exception e) {
			return false;
		}
	}
	
	

}
