package com.capgemini.pages;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.capgemini.test.TestBase;

public class Personal {
	
	WebDriver driver;

	public Personal() throws InterruptedException {
		super();
		driver=TestBase.Initialisation();
		driver.get(
				"C:\\sts-bundle\\BDD_Module3\\EmployeePOMExample\\WebContent\\Personal.html");
		Thread.sleep(1000);
	}
	
	
	public void setEmployeeDetails(String arg1, String arg2, String arg3, String arg4) throws InterruptedException
	{
		WebElement id = driver.findElement(By.name("empno"));
		id.click();
		id.sendKeys(arg1);
		Thread.sleep(1000);

		WebElement name = driver.findElement(By.name("name"));
		name.click();
		name.sendKeys(arg2);
		Thread.sleep(1000);

		Select city = new Select(driver.findElement(By.name("city")));
		city.selectByVisibleText(arg3);

		WebElement state = driver.findElement(By.name("state"));
		state.click();
		state.sendKeys(arg4);
		Thread.sleep(1000);
	}
	
	
	public void submitDetails()
	{
		driver.findElement(By.name("Submit Button")).click();
	}
	
	
	public String getTitle()
	{
		String title=driver.getTitle();
		return title;
	}
	
	
	public void quitPage()
	{
		driver.close();
	}
	
	
	public String getMessage()
	{
		String alertMessage=null;
		if (this.isAlertPresent()) {
			alertMessage=driver.switchTo().alert().getText();
			driver.switchTo().alert().accept();
		}
		return alertMessage;
	}
	
	
	public boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			return true;
		} catch (Exception e) {
			return false;
		}
	}
	
	
	

}
