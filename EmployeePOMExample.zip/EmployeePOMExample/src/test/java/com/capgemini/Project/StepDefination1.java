package com.capgemini.Project;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import com.capgemini.pages.Project;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefination1 {
	Project projectPage;
	
	

@Given("^I have a Project Detail form$")
public void i_have_a_Project_Detail_form() throws InterruptedException {
	projectPage= new Project();
	
}

@When("^Project name is \"([^\"]*)\" and Project Platform is \"([^\"]*)\"$")
public void project_name_is_and_Project_Platform_is(String arg1, String arg2) throws InterruptedException {
	
	projectPage.setProjectDetails(arg1, arg2);
	
}
	
	
	@Then("^Proceed to Next Page having the title as \"([^\"]*)\"$")
	public void proceed_to_Next_Page_having_the_title_as(String arg1){

		projectPage.submitDetails();
		String title=projectPage.getTitle();
		assertEquals(arg1,title);
		projectPage.quitPage();
	}

	
	@Then("^Show a popup Alert Message as \"([^\"]*)\"$")
	public void show_a_popup_Alert_Message_as(String arg1){
		projectPage.submitDetails();
		String alertMessage = projectPage.getMessage();
				if(alertMessage!=null)
		assertEquals(alertMessage, arg1);
		projectPage.quitPage();
	}
		
}
