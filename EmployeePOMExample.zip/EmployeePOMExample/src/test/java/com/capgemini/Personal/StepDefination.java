package com.capgemini.Personal;



import static org.junit.Assert.assertEquals;

import com.capgemini.pages.Personal;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefination {
	Personal personalPage;

	@Given("^I have a Personal detail form$")
	public void i_have_a_Personal_detail_form() throws InterruptedException {
		personalPage= new Personal();

	}

	@When("^Employee Id is \"([^\"]*)\", name \"([^\"]*)\", city \"([^\"]*)\" and State \"([^\"]*)\"$")
	public void employee_Id_is_name_city_and_State(String arg1, String arg2, String arg3, String arg4)
			throws InterruptedException {
		personalPage.setEmployeeDetails(arg1, arg2, arg3, arg4);

	}

	
	
	
	@Then("^Proceed to Next Page having the title as \"([^\"]*)\"$")
	public void proceed_to_Next_Page_having_the_title_as(String arg1) {
		personalPage.submitDetails();
		String title=personalPage.getTitle();
		assertEquals(arg1,title);
		personalPage.quitPage();
		
	}

	@Then("^Show a popup Alert Message as \"([^\"]*)\"$")
	public void show_a_popup_Alert_Message_as(String arg1){
		personalPage.submitDetails();
		String message=personalPage.getMessage();
		if(message!=null)
		assertEquals(message, arg1);
		personalPage.quitPage();
	}
	

	
	


}
