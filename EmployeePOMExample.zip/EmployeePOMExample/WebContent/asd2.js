function validateForm() {
	var projectName=document.forms["Project"]["name"].value;
	
	if(projectName=="")
	{
	alert("Project Name can not be Empty");
	return false;
	}
}